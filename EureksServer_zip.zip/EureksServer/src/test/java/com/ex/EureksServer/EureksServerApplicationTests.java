package com.ex.EureksServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EureksServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
